package com.in28minutes.web.services.soap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoapWebServicesIn10StepsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoapWebServicesIn10StepsApplication.class, args);
	}
}
