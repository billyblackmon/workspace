package com.example.demo.entity;

import javax.persistence.Entity;

@Entity
public class FullTimeEmployee extends Employee {
	protected Integer salary;
}