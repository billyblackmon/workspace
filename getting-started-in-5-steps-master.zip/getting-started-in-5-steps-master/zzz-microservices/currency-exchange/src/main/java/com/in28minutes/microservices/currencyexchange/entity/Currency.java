package com.in28minutes.microservices.currencyexchange.entity;

public enum Currency {
	INR,USD,EUR
}
