insert into exchange_value
values(10001, 'USD', 'INR', 65);
insert into exchange_value
values(10002, 'EUR', 'INR', 75);