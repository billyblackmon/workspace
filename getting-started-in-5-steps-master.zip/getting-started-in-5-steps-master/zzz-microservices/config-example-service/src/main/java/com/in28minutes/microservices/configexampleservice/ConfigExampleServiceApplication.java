package com.in28minutes.microservices.configexampleservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfigExampleServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConfigExampleServiceApplication.class, args);
	}
}
