package com.in28minutes.spring.basics.springin5steps.profiles;

public interface Cacheable {
	void doSomething();
}
