package com.in28minutes.spring.basics.springin5steps.basics;

public interface SortAlgorithm {
	public int[] sort(int[] numbers);
}
