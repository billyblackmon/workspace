package com.in28minutes.jpa.jpademo.relationships.entity;
public enum ReviewRating {
	ONE,TWO,THREE,FOUR,FIVE
}
