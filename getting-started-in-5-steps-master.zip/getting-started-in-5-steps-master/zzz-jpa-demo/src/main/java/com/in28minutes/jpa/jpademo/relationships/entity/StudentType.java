package com.in28minutes.jpa.jpademo.relationships.entity;
public enum StudentType {
	FullTime, PartTime
}
