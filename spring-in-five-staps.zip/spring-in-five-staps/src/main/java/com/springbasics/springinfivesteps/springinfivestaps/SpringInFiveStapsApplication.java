package com.springbasics.springinfivesteps.springinfivestaps;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringInFiveStapsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringInFiveStapsApplication.class, args);
	}
}
